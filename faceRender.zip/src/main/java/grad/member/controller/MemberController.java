package grad.member.controller;

public class MemberController {

}
