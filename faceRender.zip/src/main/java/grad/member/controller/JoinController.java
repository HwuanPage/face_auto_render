package grad.member.controller;

public class JoinController {

}
