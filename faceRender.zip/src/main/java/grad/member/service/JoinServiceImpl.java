package grad.member.service;

public class JoinServiceImpl {

}
