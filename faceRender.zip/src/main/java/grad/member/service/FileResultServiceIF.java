package grad.member.service;

public interface FileResultServiceIF {

}
